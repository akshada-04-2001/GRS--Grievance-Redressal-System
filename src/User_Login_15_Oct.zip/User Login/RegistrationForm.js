import React, { useState } from 'react';
import axios from 'axios';
import './RegistrationForm.css'; // Import CSS for styling
import { useNavigate } from 'react-router-dom';
const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    mobile: '',
    password: '',
    confirmPassword: '',
    gender: 'male',
    occupation: '',
  });

  const navigate = useNavigate();

  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const validateForm = () => {
    const newErrors = {};
    const namePattern = /^[A-Za-z]+$/; // Regular expression for alphabetic characters only
  
    if (!formData.firstName) {
      newErrors.firstName = 'First Name is required';
    } else if (!namePattern.test(formData.firstName)) {
      newErrors.firstName = 'First Name can only contain letters';
    } else if (formData.firstName.length > 60) { // Check for maximum length
      newErrors.firstName = 'First Name must not exceed 60 characters';
    }
  
    if (!formData.lastName) {
      newErrors.lastName = 'Last Name is required';
    } else if (!namePattern.test(formData.lastName)) {
      newErrors.lastName = 'Last Name can only contain letters';
    } else if (formData.lastName.length > 60) { // Check for maximum length
      newErrors.lastName = 'Last Name must not exceed 60 characters';
    }
  
    if (!formData.email) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Email is invalid';
    if (!formData.mobile) newErrors.mobile = 'Mobile Number is required';
    else if (!/^[0-9]{10}$/.test(formData.mobile)) newErrors.mobile = 'Mobile Number must be 10 digits';

    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{12,}$/;

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (!passwordPattern.test(formData.password)) {
      newErrors.password = 'Password must be at least 12 characters, and include at least 1 uppercase letter, 1 lowercase letter, 1 number, and 1 special character';
    }
  
    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Confirm Password is required';
    } else if (formData.confirmPassword !== formData.password) {
      newErrors.confirmPassword = 'Passwords must match';
    }

    if (!formData.occupation) newErrors.occupation = 'Occupation is required';
    else if (formData.occupation.length > 60) { // Check for maximum length
      newErrors.occupation = 'Occupation must not exceed 60 characters';
    }
  
    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});

    try {
      const response = await axios.post('http://localhost:8989/register', formData);
      console.log('Registration successful:', response.data);
      setSubmitted(true);
      alert('Registration successful!'); // Alert for successful registration
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        mobile: '',
        password: '',
        confirmPassword: '',
        gender: 'male',
        occupation: '',
      });

      navigate('/user-login');
    } catch (error) {
      if (error.response && error.response.status === 409) {
        alert('Account already exists with this email.'); 
        setErrors({ email: 'Account already exists with this email.' });
      } else {
        console.error('Error registering user:', error);
        setErrors({ api: 'Failed to register user. Please try again.' });
        alert('Failed to register user. Please try again.'); 
      }
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword((prevShowPassword) => !prevShowPassword);
  };

  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword((prevShowConfirmPassword) => !prevShowConfirmPassword);
  };

  return (
    <div className="container">
      <h2>Registration Form</h2>
      {errors.api && <div className="error">{errors.api}</div>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="firstName">First Name</label>
          <input
            type="text"
            id="firstName"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
            className="form-control"
          />
          {errors.firstName && <div className="error">{errors.firstName}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="lastName">Last Name</label>
          <input
            type="text"
            id="lastName"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
            className="form-control"
          />
          {errors.lastName && <div className="error">{errors.lastName}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="form-control"
          />
          {errors.email && <div className="error">{errors.email}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="mobile">Mobile Number</label>
          <input
            type="text"
            id="mobile"
            name="mobile"
            value={formData.mobile}
            onChange={handleChange}
            className="form-control"
          />
          {errors.mobile && <div className="error">{errors.mobile}</div>}
        </div>

        <div className="form-group">
  <label htmlFor="password">Password</label>
  <div className="input-group">
    <input
      type={showPassword ? "text" : "password"}
      id="password"
      name="password"
      value={formData.password}
      onChange={handleChange}
      className="form-control"
      placeholder="Enter Password"
    />
    <button
      type="button"
      className="input-group-append eye-button"
      onClick={togglePasswordVisibility}
    >
      {showPassword ? "🙈" : "👁️"}
    </button>
  </div>
  {errors.password && <div className="error">{errors.password}</div>}
</div>

<div className="form-group">
  <label htmlFor="confirmPassword">Confirm Password</label>
  <div className="input-group">
    <input
      type={showConfirmPassword ? "text" : "password"}
      id="confirmPassword"
      name="confirmPassword"
      value={formData.confirmPassword}
      onChange={handleChange}
      className="form-control"
      placeholder="Confirm Password"
    />
    <button
      type="button"
      className="input-group-append eye-button"
      onClick={toggleConfirmPasswordVisibility}
    >
      {showConfirmPassword ? "🙈" : "👁️"}
    </button>
  </div>
  {errors.confirmPassword && <div className="error">{errors.confirmPassword}</div>}
</div>


        <div className="form-group">
          <label>Gender</label>
          <div className="gender-options">
            <label>
              <input
                type="radio"
                name="gender"
                value="male"
                checked={formData.gender === 'male'}
                onChange={handleChange}
              /> Male
            </label>
            <label>
              <input
                type="radio"
                name="gender"
                value="female"
                checked={formData.gender === 'female'}
                onChange={handleChange}
              /> Female
            </label>
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="occupation">Occupation</label>
          <input
            type="text"
            id="occupation"
            name="occupation"
            value={formData.occupation}
            onChange={handleChange}
            className="form-control"
          />
          {errors.occupation && <div className="error">{errors.occupation}</div>}
        </div>

        <button type="submit" className="btn btn-primary">Register</button>
      </form>
      <div className="form-group">
        <p>You are already registered? <a href="/user-login">Click here for login</a></p>
      </div>
    </div>
  );
};

export default RegistrationForm;
