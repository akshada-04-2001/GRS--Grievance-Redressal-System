import React, { useEffect, useState } from "react"; 
import axios from 'axios';  // Import Axios for making HTTP requests
import GrievanceTable from "./GrievanceTable";
import "./Modal.css";

const EmployeeGrievanceReport = () => {
  // State to store grievances
  const [grievances, setGrievances] = useState([]);

  // Fetch grievance data from the backend API
  useEffect(() => {
    const fetchGrievances = async () => {
      try {
        // Update the URL to match your backend API endpoint
        const response = await axios.get('http://localhost:8989/grievance'); // Adjust the URL if needed
        console.log("Fetched grievances:", response.data);
        setGrievances(response.data); // Update state with the fetched data
      } catch (error) {
        console.error("Error fetching grievances:", error);
      }
    };

    fetchGrievances();
  }, []); // Empty dependency array to run only once when the component mounts

  const updateGrievanceStatus = (
    grievanceId,
    newStatus,
    rejectReason = null
  ) => {
    setGrievances((prevGrievances) =>
      prevGrievances.map((g) =>
        g.grievanceId === grievanceId
          ? { ...g, status: newStatus, rejectReason }
          : g
      )
    );
  };

  const handleAccept = async (grievanceId) => {
    try {
      const grievance = grievances.find((g) => g.grievanceId === grievanceId);
      const updatedGrievance = { ...grievance, status: 'accepted' };
      await axios.put(`http://localhost:8989/grievance/${grievanceId}`, updatedGrievance);
      updateGrievanceStatus(grievanceId, "accepted");
    } catch (error) {
      console.error("Error accepting grievance:", error);
    }
  };

  const handleReject = async (grievanceId, reason) => {
    try {
      const grievance = grievances.find((g) => g.grievanceId === grievanceId);
      const updatedGrievance = { ...grievance, status: 'rejected', rejectReason: reason };
      await axios.put(`http://localhost:8989/grievance/${grievanceId}`, updatedGrievance);
      updateGrievanceStatus(grievanceId, "rejected", reason);
      alert(`Grievance ${grievanceId} rejected with reason: ${reason}`);
    } catch (error) {
      console.error("Error rejecting grievance:", error);
    }
  };

  const handleTransfer = async (grievanceId, transferDetails) => {
    try {
      const grievance = grievances.find((g) => g.grievanceId === grievanceId);
      const updatedGrievance = {
        ...grievance,
        department: transferDetails.department,
        status: "transferred",
        assignedTo: transferDetails.employeeName,
        designation: transferDetails.designation,
      };
      await axios.put(`http://localhost:8989/grievance/${grievanceId}`, updatedGrievance);
      setGrievances((prevGrievances) =>
        prevGrievances.map((g) =>
          g.grievanceId === grievanceId
            ? updatedGrievance
            : g
        )
      );
      alert(
        `Grievance ${grievanceId} transferred to ${transferDetails.employeeName} (${transferDetails.designation} in ${transferDetails.department})`
      );
    } catch (error) {
      console.error("Error transferring grievance:", error);
    }
  };

  const handleResolve = async (grievanceId) => {
    try {
      const grievance = grievances.find((g) => g.grievanceId === grievanceId);
      const updatedGrievance = { ...grievance, status: 'resolved' };
      await axios.put(`http://localhost:8989/grievance/${grievanceId}`, updatedGrievance);
      updateGrievanceStatus(grievanceId, "resolved");
      alert(`Grievance ${grievanceId} resolved successfully.`);
    } catch (error) {
      console.error("Error resolving grievance:", error);
    }
  };

  return (
    <div className="container mt-5">
      <h3>EMPLOYEE GRIEVANCE REPORT</h3>
      <GrievanceTable
        grievances={grievances}
        onAccept={handleAccept}
        onReject={handleReject}
        onTransfer={handleTransfer}
        onResolve={handleResolve}
      />
    </div>
  );
};

export default EmployeeGrievanceReport;
