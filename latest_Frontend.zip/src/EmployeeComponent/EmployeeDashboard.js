import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Button,
} from '@mui/material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const EmployeeDashboard = () => {
  const [data, setData] = useState([
    { name: 'Pending', count: 3 },
    { name: 'Resolved', count: 4 },
    { name: 'In Progress', count: 6 },
  ]);

  const navigate = useNavigate();  // Hook to navigate to other pages

  // Fetch grievance data and update chart
  useEffect(() => {
    const fetchGrievanceData = async () => {
      try {
        // Simulated API response
        const response = await axios.get('http://localhost:3000/grievances');  // Replace with your API endpoint
        const fetchedGrievances = response.data;

        // Calculate status counts
        const pendingCount = fetchedGrievances.filter(grievance => grievance.status === 'Pending').length;
        const resolvedCount = fetchedGrievances.filter(grievance => grievance.status === 'Resolved').length;
        const inProgressCount = fetchedGrievances.filter(grievance => grievance.status === 'In Progress').length;

        // Update chart data
        setData([
          { name: 'Pending', count: pendingCount },
          { name: 'Resolved', count: resolvedCount },
          { name: 'In Progress', count: inProgressCount },
        ]);
      } catch (error) {
        console.error('Error fetching grievance data:', error);
      }
    };

    fetchGrievanceData(); // Fetch data on component mount
  }, []);

  // Handle button click to navigate to employee report page
  const handleReportClick = () => {
    navigate('/employee-grievancereport');
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mt: 4 }}>
      {/* Heading at the top */}
      <Typography variant="h4" gutterBottom>
        Employee Dashboard
      </Typography>

      {/* Centered content */}
      <Card sx={{ width: '400px', textAlign: 'center', mb: 2 }}>
        <CardContent>
          <Typography variant="h6" align="left" gutterBottom>
            Status Overview
          </Typography>

          {/* Bar Chart */}
          <ResponsiveContainer width="100%" height={200}>
            <BarChart
              data={data}
              margin={{
                top: 20, right: 30, left: 20, bottom: 20,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis 
                tickCount={6}      // Set number of ticks (i.e., 0, 2, 4, 6, 8, 10)
                domain={[0, 10]}   // Set the Y-axis range from 0 to 10
                ticks={[0, 2, 4, 6, 8, 10]} // Explicitly set the ticks to be displayed
              />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Button for Employee Report, centered under the chart */}
      <Button variant="contained" color="primary" onClick={handleReportClick}>
        Employee Report
      </Button>
    </Box>
  );
};

export default EmployeeDashboard;
