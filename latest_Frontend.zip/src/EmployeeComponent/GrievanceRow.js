import React, { useState } from "react"; 

const GrievanceRow = ({
  grievance,
  onAccept,
  onReject,
  onTransfer,
  onResolve,
}) => {
  const [showRejectReason, setShowRejectReason] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [transferDetails, setTransferDetails] = useState({
    department: "",
    designation: "",
    employeeName: "",
  });

  const handleReject = () => {
    setShowRejectReason(true);
  };

  const handleRejectSubmit = () => {
    onReject(grievance.grievanceId, rejectReason);
    setShowRejectReason(false);
  };

  const handleTransferSubmit = () => {
    const { department, designation, employeeName } = transferDetails;

    // Check if any field is empty
    if (!department || !designation || !employeeName) {
      alert("Please fill out the form correctly.");
    } else {
      // Call onTransfer function to update the parent component state
      onTransfer(grievance.grievanceId, transferDetails);

      // Close the modal after submission
      setShowTransferModal(false);
    }
  };

  return (
    <>
      <tr>
        <td>{grievance.grievanceId}</td>
        <td>{grievance.date}</td>
        <td>{grievance.complainantName}</td>
        <td>{grievance.department}</td>
        <td>{grievance.grievanceType}</td>
        <td>{grievance.status}</td>
        <td>
          {grievance.status === "pending" && (
            <>
              <button
                className="btn btn-success m-2"
                onClick={() => onAccept(grievance.grievanceId)}
              >
                Accept
              </button>
              <button className="btn btn-danger m-2" onClick={handleReject}>
                Reject
              </button>
            </>
          )}
          {grievance.status === "accepted" && (
            <>
              <button
                className="btn btn-warning m-2"
                onClick={() => setShowTransferModal(true)}
              >
                Transfer
              </button>
              <button
                className="btn btn-primary m-2"
                onClick={() => onResolve(grievance.grievanceId)}
              >
                Resolve
              </button>
            </>
          )}
        </td>
        {showRejectReason && (
          <td>
            <textarea
              placeholder="Enter reason for rejection"
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
            />
            <button className="btn btn-danger m-2" onClick={handleRejectSubmit}>
              Submit Reject
            </button>
          </td>
        )}
      </tr>

      {/* Transfer Modal */}
      {showTransferModal && (
        <div className="modal-backdrop">
          <div className="modal-content">
            <h5>Transfer Grievance</h5>
            <label>Department:</label>
            <select
              value={transferDetails.department}
              onChange={(e) =>
                setTransferDetails({
                  ...transferDetails,
                  department: e.target.value,
                })
              }
            >
              <option value="">Select Department</option>
              <option value="Finance">Finance</option>
              <option value="HR">HR</option>
              <option value="IT">IT</option>
              <option value="Operations">Operations</option>
            </select>

            <label>Designation:</label>
            <select
              value={transferDetails.designation}
              onChange={(e) =>
                setTransferDetails({
                  ...transferDetails,
                  designation: e.target.value,
                })
              }
            >
              <option value="">Select Designation</option>
              <option value="Manager">Manager</option>
              <option value="Senior Staff">Senior Staff</option>
              <option value="Junior Staff">Junior Staff</option>
            </select>

            <label>Employee Name:</label>
            <input
              type="text"
              placeholder="Enter Name"
              value={transferDetails.employeeName}
              onChange={(e) =>
                setTransferDetails({
                  ...transferDetails,
                  employeeName: e.target.value,
                })
              }
            />

            <div className="modal-actions">
              <button
                className="btn btn-primary"
                onClick={handleTransferSubmit}
              >
                Submit Transfer
              </button>
              <button
                className="btn btn-secondary"
                onClick={() => setShowTransferModal(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default GrievanceRow;
