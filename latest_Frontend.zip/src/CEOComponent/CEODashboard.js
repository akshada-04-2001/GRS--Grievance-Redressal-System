import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, Row, Col, Card, Button, Table } from 'react-bootstrap';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, LineChart, Line, Legend } from 'recharts';
import './CEODashboard.css';

const CEODashboard = () => {
  const [grievanceCounts, setGrievanceCounts] = useState({
    pending: 0,
    resolved: 0,
  });
  
  const [departmentWiseData, setDepartmentWiseData] = useState([]);
  const [topEmployees, setTopEmployees] = useState([]);
  const [dailyGrievanceTrend, setDailyGrievanceTrend] = useState([]);

  useEffect(() => {
    axios.get('/api/grievances/counts')
      .then(response => {
        setGrievanceCounts(response.data);
      })
      .catch(error => console.error('Error fetching grievance counts:', error));

    axios.get('/api/grievances/department-wise')
      .then(response => {
        setDepartmentWiseData(response.data);
      })
      .catch(error => console.error('Error fetching department-wise grievances:', error));

    axios.get('/api/employees/top-pending')
      .then(response => {
        setTopEmployees(response.data);
      })
      .catch(error => console.error('Error fetching top employees:', error));

    axios.get('/api/grievances/daily-trends')
      .then(response => {
        setDailyGrievanceTrend(response.data);
      })
      .catch(error => console.error('Error fetching daily grievance trends:', error));
  }, []);

  return (
    <Container fluid>
      {}
      <Row className="mb-4">
        <Col md={4}>
          <Card>
            <Card.Body>
              <Card.Title>Grievance Counts</Card.Title>
              <Card.Text>Pending: {grievanceCounts.pending}</Card.Text>
              <Card.Text>Resolved: {grievanceCounts.resolved}</Card.Text>
            </Card.Body>
          </Card>
        </Col>

        {}
        <Col md={8}>
          <Card>
            <Card.Body>
              <Card.Title>Department-wise Breakdown</Card.Title>
              <BarChart width={600} height={300} data={departmentWiseData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="department" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="grievances" fill="#82ca9d" />
              </BarChart>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {}
      <Row className="mb-4">
        <Col>
          <Card>
            <Card.Body>
              <Card.Title>Employees with Pending Grievances</Card.Title>
              <Table striped bordered hover>
                <thead>
                  <tr>
                    <th>Employee Name</th>
                    <th>Pending Grievances</th>
                  </tr>
                </thead>
                <tbody>
                  {topEmployees.map((employee, index) => (
                    <tr key={index}>
                      <td>{employee.name}</td>
                      <td>{employee.pending}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {}
      <Row className="mb-4">
        <Col>
          <Card>
            <Card.Body>
              <Card.Title>Daily Grievance Chart</Card.Title>
              <LineChart width={600} height={300} data={dailyGrievanceTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="grievances" stroke="#8884d8" />
              </LineChart>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {}
      <Row>
        <Col>
          <Button variant="primary" size="lg" onClick={() => window.location.href = '/ceo/grievance-report'}>
            View Grievance Report
          </Button>
        </Col>
      </Row>
    </Container>
  );
};

export default CEODashboard;
