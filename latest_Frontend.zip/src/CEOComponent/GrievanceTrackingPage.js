import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './GrievanceTrackingPage.css'; // Import the CSS file

const GrievanceTrackingPage = () => {
  const [searchId, setSearchId] = useState('');
  const [grievance, setGrievance] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Fetch grievances from API on component mount
  useEffect(() => {
    const fetchGrievances = async () => {
      try {
        const response = await axios.get('https://api.example.com/grievances'); // Replace with your API URL
        setGrievance(response.data);
      } catch (err) {
        setError('Failed to fetch grievances. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchGrievances();
  }, []);

  const handleSearch = () => {
    const foundGrievance = grievance.find(g => g.id === parseInt(searchId));
    setGrievance(foundGrievance || null);
  };

  useEffect(() => {
    if (!searchId) {
      setGrievance(null);
    }
  }, [searchId]);

  return (
    <div className="container">
      <h1 className="title">Grievance Tracking</h1>
      
      <div className="search-container">
        <input 
          type="number" 
          placeholder="Enter Grievance Number" 
          value={searchId} 
          onChange={(e) => setSearchId(e.target.value)} 
          className="input"
        />
        <button onClick={handleSearch} className="button">Search</button>
      </div>

      {loading && <p className="loading-message">Loading grievances...</p>}
      {error && <p className="error-message">{error}</p>}

      {grievance ? (
        <div className="grievance-container">
          <h2 className="grievance-title">Grievance {grievance.id}: {grievance.title}</h2>
          <h3 className="timeline-title">Timeline:</h3>
          <ul className="timeline-list">
            {grievance.history.map((entry, index) => (
              <li key={index} className="timeline-item">
                <strong>{entry.timestamp}</strong>: {entry.action} by {entry.responsible}
              </li>
            ))}
          </ul>
        </div>
      ) : (
        searchId && <p className="no-grievance-message">No grievance found with this number.</p>
      )}
    </div>
  );
};

export default GrievanceTrackingPage;
