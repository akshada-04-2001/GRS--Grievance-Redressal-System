import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Grid,
  MenuItem,
} from '@mui/material';

// Mock data for grievances
const mockGrievanceData = [
  { id: 1, grievanceNumber: 'G001', date: '2024-09-01', department: 'HR', employee: 'VIVEK', status: 'Pending' },
  { id: 2, grievanceNumber: 'G002', date: '2024-09-02', department: 'IT', employee: 'Kartik', status: 'Resolved' },
  { id: 1, grievanceNumber: 'G001', date: '2024-09-01', department: 'HR', employee: 'Gaurav', status: 'Pending' },
];

const CEOGrievanceReport = () => {
  const [grievances, setGrievances] = useState(mockGrievanceData);
  const [filters, setFilters] = useState({
    dateRange: '',
    status: '',
    department: '',
  });

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({ ...filters, [name]: value });
  };

  const filteredGrievances = grievances.filter(
    (grievance) =>
      (!filters.dateRange || grievance.date === filters.dateRange) &&
      (!filters.status || grievance.status === filters.status) &&
      (!filters.department || grievance.department === filters.department)
  );

  return (
    <Box sx={{ padding: '20px' }}>
      <Typography variant="h4" gutterBottom>
        CEO Grievance Report
      </Typography>

      {/* Filters */}
      <Grid container spacing={2} sx={{ marginBottom: 2 }}>
        <Grid item xs={12} md={4}>
          <TextField
            label="Date Range"
            type="date"
            fullWidth
            name="dateRange"
            value={filters.dateRange}
            onChange={handleFilterChange}
            InputLabelProps={{ shrink: true }}
          />
        </Grid>
        <Grid item xs={12} md={4}>
          <TextField
            label="Status"
            select
            fullWidth
            name="status"
            value={filters.status}
            onChange={handleFilterChange}
          >
            <MenuItem value="">All</MenuItem>
            <MenuItem value="Pending">Pending</MenuItem>
            <MenuItem value="Resolved">Resolved</MenuItem>
          </TextField>
        </Grid>
        <Grid item xs={12} md={4}>
          <TextField
            label="Department"
            select
            fullWidth
            name="department"
            value={filters.department}
            onChange={handleFilterChange}
          >
            <MenuItem value="">All</MenuItem>
            <MenuItem value="HR">HR</MenuItem>
            <MenuItem value="IT">IT</MenuItem>
            <MenuItem value="Finance">Finance</MenuItem>
          </TextField>
        </Grid>
      </Grid>

      {/* Grievance Table */}
      <TableContainer component={Paper}>
        <Table aria-label="grievance table">
          <TableHead>
            <TableRow>
              <TableCell>Grievance Number</TableCell>
              <TableCell>Date</TableCell>
              <TableCell>Department</TableCell>
              <TableCell>Employee Assigned</TableCell>
              <TableCell>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredGrievances.map((grievance) => (
              <TableRow key={grievance.id}>
                <TableCell>{grievance.grievanceNumber}</TableCell>
                <TableCell>{grievance.date}</TableCell>
                <TableCell>{grievance.department}</TableCell>
                <TableCell>{grievance.employee}</TableCell>
                <TableCell>{grievance.status}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default CEOGrievanceReport;
